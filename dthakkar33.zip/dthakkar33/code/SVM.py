import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import learning_curve
from sklearn.metrics import accuracy_score, confusion_matrix
from sklearn import svm
import matplotlib.pyplot as plt
import datetime
import warnings
warnings.simplefilter('ignore')

def plot_learning_curve(estimator, title, X, y, ylim=None, cv=None,
                        n_jobs=1, train_sizes=np.linspace(.1, 1.0, 5)):
    """
    Generate a simple plot of the test and training learning curve.

    Parameters
    ----------
    estimator : object type that implements the "fit" and "predict" methods
        An object of that type which is cloned for each validation.

    title : string
        Title for the chart.

    X : array-like, shape (n_samples, n_features)
        Training vector, where n_samples is the number of samples and
        n_features is the number of features.

    y : array-like, shape (n_samples) or (n_samples, n_features), optional
        Target relative to X for classification or regression;
        None for unsupervised learning.

    ylim : tuple, shape (ymin, ymax), optional
        Defines minimum and maximum yvalues plotted.

    cv : int, cross-validation generator or an iterable, optional
        Determines the cross-validation splitting strategy.
        Possible inputs for cv are:
          - None, to use the default 3-fold cross-validation,
          - integer, to specify the number of folds.
          - An object to be used as a cross-validation generator.
          - An iterable yielding train/test splits.

        For integer/None inputs, if ``y`` is binary or multiclass,
        :class:`StratifiedKFold` used. If the estimator is not a classifier
        or if ``y`` is neither binary nor multiclass, :class:`KFold` is used.

        Refer :ref:`User Guide <cross_validation>` for the various
        cross-validators that can be used here.

    n_jobs : integer, optional
        Number of jobs to run in parallel (default 1).
    """
    plt.figure()
    plt.title(title)
    if ylim is not None:
        plt.ylim(*ylim)
    plt.xlabel("Training examples")
    plt.ylabel("Score")
    train_sizes, train_scores, test_scores = learning_curve(
        estimator, X, y, cv=cv, n_jobs=n_jobs, train_sizes=train_sizes)
    train_scores_mean = np.mean(train_scores, axis=1)
    train_scores_std = np.std(train_scores, axis=1)
    test_scores_mean = np.mean(test_scores, axis=1)
    test_scores_std = np.std(test_scores, axis=1)
    plt.grid()

    plt.fill_between(train_sizes, train_scores_mean - train_scores_std,
                     train_scores_mean + train_scores_std, alpha=0.1,
                     color="r")
    plt.fill_between(train_sizes, test_scores_mean - test_scores_std,
                     test_scores_mean + test_scores_std, alpha=0.1, color="g")
    plt.plot(train_sizes, train_scores_mean, 'o-', color="r",
             label="Training score")
    plt.plot(train_sizes, test_scores_mean, 'o-', color="g",
             label="Cross-validation score")

    plt.legend(loc="best")
    plt.show()
    return plt

def SVMClassifier():
    
    #Uncomment to get winequality data
    d = pd.read_csv('../data/winequality-white.csv')
    X = d.iloc[:,:11]
    Y = d.iloc[:,11]
    
    #Uncomment to get breast cancer data
#     d = pd.read_csv('../data/breast_cancer.csv')
#     X = d.iloc[:,1:10]
#     Y = d.iloc[:,10]
    
    X_train, X_test, Y_train, Y_test = train_test_split(X, Y, random_state=1,shuffle=True,test_size=0.20)
    scaler = StandardScaler(copy=True, with_mean=True, with_std=True)
    scaler.fit(X_train)
    scaler.fit(X_test)
    X_train = scaler.transform(X_train)
    X_test = scaler.transform(X_test)

    kernels = ['linear', 'poly', 'rbf']
    for kernel in kernels:
        svc = svm.SVC(kernel=kernel).fit(X_train, Y_train.ravel())
        preds = svc.predict(X_test)
        print(str(kernel)+"  "+str(accuracy_score(Y_test, preds)))

    clf = svm.SVC(kernel='rbf')
    start_time = datetime.datetime.now()
    clf = clf.fit(X_train, Y_train)
    end_time = datetime.datetime.now()
    delta = end_time - start_time
    train_predict = clf.predict(X_train)
    test_predict = clf.predict(X_test)
    print("Time taken to train SVM Classifier is " + str(int(delta.total_seconds() * 1000)) + " ms")
    print("The training accuracy of SVM Classifier is ", str(accuracy_score(Y_train, train_predict)))
    print("The testing accuracy of SVM Classifier is " + str(accuracy_score(Y_test, test_predict)))    
    plot_learning_curve(clf, "RBF Kernel" , X, Y, ylim=[0,1], cv=5)    
    
if __name__ == '__main__':
    SVMClassifier()