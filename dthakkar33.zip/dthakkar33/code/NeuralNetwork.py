import pandas as pd
import tensorflow as tf
import numpy as np
from sklearn.model_selection import train_test_split, cross_val_score, StratifiedKFold, learning_curve
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import accuracy_score
from sklearn import preprocessing
from keras.models import Sequential
from keras.layers import Dense, Activation
import matplotlib.pyplot as plt
import os
os.environ['KERAS_BACKEND'] = 'tensorflow'
import datetime
import warnings
warnings.simplefilter('ignore')


#10 labels (0-10) for wine quality, 11 features
def get_wine_data():
    label_col = 'quality'
    df = pd.read_csv('../data/winequality-white.csv')
    cols = np.asarray(df.columns)
    Y = np.asarray(df[label_col].values)
    Y = Y.reshape(Y.shape[0],1)
    df.drop(label_col, axis=1, inplace=True)
    X = np.asarray(df.values)

    return X,Y,cols

#2 labels Breast Cancer present/not present(1/0), 9 features, 1 column does not help in classification
def get_breast_cancer_data():
    label_col = 'class'
    #https://www.kaggle.com/johnyquest/wisconsin-breast-cancer-cytology
    df = pd.read_csv('../data/breast_cancer.csv').dropna()
    df.drop('id', axis=1, inplace=True)        #This column doesn't help in classification
    cols = np.asarray(df.columns)
    Y = np.asarray(df[label_col].values)
    Y = Y.reshape(Y.shape[0],1)
    df.drop(label_col, axis=1, inplace=True)
    X = np.asarray(df.values)

    return X,Y,cols



def plot_learning_curve(estimator, title, X, y, ylim=None, cv=None,
                        n_jobs=1, train_sizes=np.linspace(.1, 1.0, 5)):
    """
    Generate a simple plot of the test and training learning curve.

    Parameters
    ----------
    estimator : object type that implements the "fit" and "predict" methods
        An object of that type which is cloned for each validation.

    title : string
        Title for the chart.

    X : array-like, shape (n_samples, n_features)
        Training vector, where n_samples is the number of samples and
        n_features is the number of features.

    y : array-like, shape (n_samples) or (n_samples, n_features), optional
        Target relative to X for classification or regression;
        None for unsupervised learning.

    ylim : tuple, shape (ymin, ymax), optional
        Defines minimum and maximum yvalues plotted.

    cv : int, cross-validation generator or an iterable, optional
        Determines the cross-validation splitting strategy.
        Possible inputs for cv are:
          - None, to use the default 3-fold cross-validation,
          - integer, to specify the number of folds.
          - An object to be used as a cross-validation generator.
          - An iterable yielding train/test splits.

        For integer/None inputs, if ``y`` is binary or multiclass,
        :class:`StratifiedKFold` used. If the estimator is not a classifier
        or if ``y`` is neither binary nor multiclass, :class:`KFold` is used.

        Refer :ref:`User Guide <cross_validation>` for the various
        cross-validators that can be used here.

    n_jobs : integer, optional
        Number of jobs to run in parallel (default 1).
    """
    plt.figure()
    plt.title(title)
    if ylim is not None:
        plt.ylim(*ylim)
    plt.xlabel("Training examples")
    plt.ylabel("Score")
    train_sizes, train_scores, test_scores = learning_curve(
        estimator, X, y, cv=cv, n_jobs=n_jobs, train_sizes=train_sizes)
    train_scores_mean = np.mean(train_scores, axis=1)
    train_scores_std = np.std(train_scores, axis=1)
    test_scores_mean = np.mean(test_scores, axis=1)
    test_scores_std = np.std(test_scores, axis=1)
    plt.grid()
    plt.fill_between(train_sizes, train_scores_mean - train_scores_std,
                     train_scores_mean + train_scores_std, alpha=0.1,
                     color="r")
    plt.fill_between(train_sizes, test_scores_mean - test_scores_std,
                     test_scores_mean + test_scores_std, alpha=0.1, color="g")
    plt.plot(train_sizes, train_scores_mean, 'o-', color="r",
             label="Training score")
    plt.plot(train_sizes, test_scores_mean, 'o-', color="g",
             label="Cross-validation score")
    plt.legend(loc="best")
    plt.show()
    return plt


def one_hot_encoding(Y):
    temp = np.unique(Y)
    hmap = dict()
    c=0
    for i in range(0,len(temp)):
        hmap[temp[i]]=c
        c=c+1
    Y_ohc = np.zeros((Y.shape[0],len(temp)))
    for i in range(len(Y)):
        Y_ohc[i][hmap[Y[i][0]]] = 1
    return Y_ohc



def NNclassifier():
     
    X,Y,cols = get_breast_cancer_data() #get_wine_data() 

    Y_ohc = one_hot_encoding(Y)
    
    X_train, X_test, Y_train, Y_test = train_test_split(X, Y_ohc, random_state=1,shuffle=True, test_size=0.2)
    
    op_shape = Y_ohc.shape[1]
    
    model = Sequential()
    model.add(Dense(128, input_dim=X.shape[1], activation='relu'))
    model.add(Dense(64, input_dim=X.shape[1], activation='relu'))
    model.add(Dense(op_shape, activation='softmax'))
    model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
    start_time = datetime.datetime.now()
    results = model.fit( X_train, Y_train, epochs= 200, batch_size = 32, validation_data = (X_test, Y_test),verbose=0)
    end_time = datetime.datetime.now()
    delta = end_time - start_time

    plt.plot(results.history['acc'], label="Training")
    plt.plot(results.history['val_acc'], label="Testing")
    plt.legend(loc='lower right')
    plt.xlabel("Epochs")
    plt.ylabel("Accuracy")
    
    print("Time taken to train Neural Network is " + str(int(delta.total_seconds() * 1000)) + " ms")
    print("The training accuracy of Neural Network is ", str(max(results.history['acc'])))
    print("The testing accuracy of Neural Network is " + str(max(results.history['val_acc'])))
    
    clf = MLPClassifier(solver='adam', hidden_layer_sizes=(128,64,2), random_state=0, activation='tanh', max_iter = 200, batch_size=200) 
    clf = clf.fit(X_train, Y_train)
    train_predict = clf.predict(X_train)
    test_predict = clf.predict(X_test)
    plot_learning_curve(clf, "Neural Network", X, Y, ylim=[0,1])
         
if __name__ == '__main__':
    NNclassifier()